This file came out of a .tar.gz tarball.
